export enum CanvasType {
  Airboat = 'Airboat',
  Boat = 'Boat',
  DigitalGraphics = 'Digital Graphics'
}
