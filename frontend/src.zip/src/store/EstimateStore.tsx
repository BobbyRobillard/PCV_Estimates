
import { create } from 'zustand'
import { nanoid } from 'nanoid'

export interface EstimateItem {
  id: string
  mainType?: string
  subTypes?: string[]
  hullType?: string
  inspirationImages?: string[]
  uploadedImages?: { file: File; previewUrl: string }[]
  wrapPurpose?: string
  wrapLevel?: string
  installPlan?: string
  shipToPainterChic?: string
  installState?: string
  installCity?: string
  specialRequests?: string
  contactName?: string
  contactEmail?: string
  contactPhone?: string
}

interface EstimateState {
  items: EstimateItem[]
  currentItem: EstimateItem | null
  editingItemId: string | null
  currentStep: number
  goToStep: (step: number) => void
  startNewItem: () => void
  editItem: (id: string) => void
  deleteItem: (id: string) => void
  updateCurrentItem: (data: Partial<EstimateItem>) => void
  finalizeCurrentItem: () => void
  resetEstimate: () => void
}

export const useEstimateStore = create<EstimateState>((set, get) => ({
  items: [],
  currentItem: null,
  editingItemId: null,
  currentStep: 1,

  goToStep: (step) => set({ currentStep: step }),

  startNewItem: () =>
    set({
      currentItem: { id: nanoid(), subTypes: [], inspirationImages: [], uploadedImages: [] },
      editingItemId: null,
      currentStep: 1
    }),

  editItem: (id) => {
    const item = get().items.find(i => i.id === id)
    if (item) {
      set({ currentItem: { ...item }, editingItemId: id, currentStep: 1 })
    }
  },

  deleteItem: (id) =>
    set({
      items: get().items.filter(item => item.id !== id),
      currentItem: null,
      editingItemId: null
    }),

  updateCurrentItem: (data) =>
    set({
      currentItem: { ...get().currentItem, ...data }
    }),

  finalizeCurrentItem: () => {
    const { currentItem, items, editingItemId } = get()
    if (!currentItem) return
    let updatedItems = [...items]
    if (editingItemId) {
      updatedItems = items.map(item =>
        item.id === editingItemId ? currentItem : item
      )
    } else {
      updatedItems.push(currentItem)
    }
    set({
      items: updatedItems,
      currentItem: null,
      editingItemId: null
    })
  },

  resetEstimate: () =>
    set({
      items: [],
      currentItem: null,
      editingItemId: null,
      currentStep: 1
    })
}))
